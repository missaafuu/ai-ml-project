export default function HomePage() {
  return (
    <main style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1 style={{ fontSize: "2rem", marginBottom: "1rem" }}>
        AI & Machine Learning Applications in Real-World Problem Solving
      </h1>
      <p style={{ lineHeight: "1.6" }}>
        This project leverages Artificial Intelligence and Machine Learning techniques to solve real-world problems by developing predictive, classification, or automation-based models. The solution involves collecting and preprocessing data relevant to the chosen problem domain, selecting appropriate ML algorithms (such as Decision Trees, SVM, Random Forest, or Neural Networks), and training models to achieve accurate results. The trained model is then validated and deployed in a user-friendly interface (web or mobile app) to enable smart decision-making or automation.
      </p>
      <br />
      <p>Applications include:</p>
      <ul>
        <li>📍 Healthcare – disease prediction or diagnostics</li>
        <li>📍 Finance – fraud detection or stock prediction</li>
        <li>📍 Agriculture – crop yield or disease detection</li>
        <li>📍 Retail – recommendation engines or demand forecasting</li>
        <li>📍 Smart Cities – traffic prediction or waste management</li>
      </ul>
      <br />
      <h2>💻 Languages & Technologies Used:</h2>
      <ul>
        <li><strong>Programming:</strong> Python, JavaScript</li>
        <li><strong>ML Libraries:</strong> Scikit-learn, TensorFlow, Pandas, NumPy</li>
        <li><strong>Visualization:</strong> Matplotlib, Seaborn</li>
        <li><strong>Frontend:</strong> HTML, CSS, JavaScript (Next.js)</li>
        <li><strong>Deployment:</strong> GitHub, Vercel</li>
        <li><strong>Monitoring:</strong> Vercel Speed Insights</li>
      </ul>
    </main>
  );
}
